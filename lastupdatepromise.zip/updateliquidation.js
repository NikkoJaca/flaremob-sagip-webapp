var config = {
    apiKey: "AIzaSyAsREyRj2u1GDG1sKF1gyAE476u5pp2PxQ",
    authDomain: "flaremob-b55d8.firebaseapp.com",
    databaseURL: "https://flaremob-b55d8.firebaseio.com",
    projectId: "flaremob-b55d8",
    storageBucket: "flaremob-b55d8.appspot.com",
    messagingSenderId: "27793888698"
};
firebase.initializeApp(config);
var database = firebase.database().ref();
const auth = firebase.auth();

function updateluiqui() {
    var database = firebase.database().ref("tblLiquidation/TotalSpent");
    const auth = firebase.auth();
    let liquidation = database.child("BreaknTotal");
    // let valuecheck = [];
    var spent = document.getElementById('spent').value;
    // let image = document.getElementById('spent').value;
    let breakdown = document.getElementById('breakdown5').value;
    liquidation.push({
        TotalSpent:spent,
        imgrecipt:"sample",
        breakdown:breakdown
    });
    // $("input:checkbox[name=someSwitchOption002]:checked").each(function(){
    //     valuecheck.push($(this).val());
    // });
    // liquidation.orderByChild('amountDonated').on('child_added',snap=>{
    //     console.log(snap.key);
    //     let total = parseInt(snap.child('amountDonated').val())-spent ;
    //     console.log(total);
    // });
    // liquidation.orderByChild("datetimePledge").limitToFirst(5).once("value")
    //     .then(function (snap) {
    //         console.log(snap.val());
    //     })

}

function DateTimeNow(Zero29){
    var datetoday=new Date();
    var year=datetoday.getFullYear(); // 0
    var mon=datetoday.getMonth(); // 1
    var dayno=datetoday.getDate(); // 2
    var hour=datetoday.getHours(); // 3
    var min=datetoday.getMinutes(); // 4
    var sec=datetoday.getSeconds(); // to be used in option 8
    var milsec=datetoday.getMilliseconds();

    if (mon<10){mon='0'+String(mon);}
    if (dayno<10){dayno='0'+String(dayno);}
    if (hour<10){hour='0'+String(hour);}
    if (min<10){min='0'+String(min);}
    if (sec<10){sec='0'+String(sec);}
    if (milsec<10){milsec='00'+String(milsec);}
    else if(milsec<100){milsec='0'+String(milsec);}

    var date=String(year+'-'+mon+'-'+dayno); // 5
    var YearMon=String(year+'-'+mon); // 6
    var time=String(hour+':'+min); // 7
    var ISDateTime=String(date+' '+time+':'+sec);
    var AutoID=String(year+''+mon+''+dayno+''+hour+''+min+''+sec+''+milsec);

    if (Zero29==0){ return year;
    }else if(Zero29==1){ return mon;
    }else if(Zero29==2){ return dayno;
    }else if(Zero29==3){ return hour;
    }else if(Zero29==4){ return min;
    }else if(Zero29==5){ return date; //returns YYYY-MM-DD
    }else if(Zero29==6){ return YearMon; //returns YYYY-MM
    }else if(Zero29==7){ return time; //returns hh:mm
    }else if(Zero29==8){ return ISDateTime; //returns YYYY-MM-DD hh:mm:ss
    }else if(Zero29==9){ return AutoID; //returns YYYYMMDDhhmmssiii
    }else{ return date+' '+time;} //returns YYYY-MM-DD hh:mm
}
